import importlib
import pytest
from src import config, ingestion, paysim_adapter, pipeline
from tests import paysim_fixture


@pytest.fixture(autouse=True)
def profile_isolation():
    """apply_profile mutates config globals; reload config afterwards so other tests are unaffected."""
    yield
    importlib.reload(config)


@pytest.fixture()
def mock_csv(tmp_path):
    p = tmp_path / "paysim.csv"
    paysim_fixture.make().to_csv(p, index=False)
    return p


def test_adapter_maps_schema_and_truth(mock_csv):
    raw, truth = paysim_adapter.load(mock_csv, sample=0)
    assert list(raw.columns) == config.REQUIRED_COLUMNS
    assert raw["transaction_id"].is_unique and set(raw.merchant_category) <= {"MERCHANT", "CUSTOMER"}
    assert len(truth) > 0 and truth["transaction_id"].isin(raw["transaction_id"]).all()


def test_adapter_sampling_is_reproducible(mock_csv):
    a, _ = paysim_adapter.load(mock_csv, sample=5000, seed=1)
    b, _ = paysim_adapter.load(mock_csv, sample=5000, seed=1)
    assert a.equals(b) and 4000 < len(a) < 6000


def test_adapter_rejects_wrong_file(tmp_path):
    p = tmp_path / "x.csv"
    p.write_text("a,b,c\n1,2,3\n")
    with pytest.raises(ValueError):
        paysim_adapter.load(p)


def test_pipeline_runs_under_paysim_profile(mock_csv):
    config.apply_profile("paysim")
    raw, _ = paysim_adapter.load(mock_csv, sample=0)
    out = pipeline.run(ingestion.validate_schema(raw))
    r = out["results"]
    assert len(r) == len(raw) and 0 < r["anomaly_flag"].mean() < 0.2
    assert out["audit"]["features"] == config.PROFILES["paysim"]["ML_FEATURES"]
