"""MOCK file in PaySim's exact column layout, for testing the adapter/pipeline only.
It imitates PaySim's structure (types, M/C destination prefixes, fraud only in TRANSFER/CASH_OUT draining the balance).
Results on this mock say NOTHING about the real dataset."""
import numpy as np
import pandas as pd

COLS = ["step", "type", "amount", "nameOrig", "oldbalanceOrg", "newbalanceOrig", "nameDest",
        "oldbalanceDest", "newbalanceDest", "isFraud", "isFlaggedFraud"]


def make(n=30000, seed=0, fraud_rate=0.003):
    rng = np.random.default_rng(seed)
    t = rng.choice(["CASH_OUT", "PAYMENT", "CASH_IN", "TRANSFER", "DEBIT"], n, p=[.35, .34, .22, .08, .01])
    amt = np.round(rng.lognormal(np.where(t == "PAYMENT", 8.5, 10.5), 1.0), 2)
    old = np.round(amt * rng.uniform(1.0, 20.0, n), 2)
    new = np.where(t == "CASH_IN", old + amt, old - amt).round(2)
    orig = np.array([f"C{x}" for x in rng.integers(10**8, 10**9, n)])
    dest = np.where(t == "PAYMENT", [f"M{x}" for x in rng.integers(10**8, 10**9, n)],
                    [f"C{x}" for x in rng.integers(10**8, 10**9, n)])
    fraud = (np.isin(t, ["TRANSFER", "CASH_OUT"])) & (rng.random(n) < fraud_rate * 3.3)
    amt = np.where(fraud, np.round(rng.uniform(2e5, 5e6, n), 2), amt)
    old = np.where(fraud, amt, old)
    new = np.where(fraud, 0.0, new)
    return pd.DataFrame({"step": rng.integers(1, 745, n), "type": t, "amount": amt, "nameOrig": orig,
                         "oldbalanceOrg": old, "newbalanceOrig": new, "nameDest": dest,
                         "oldbalanceDest": 0.0, "newbalanceDest": 0.0, "isFraud": fraud.astype(int),
                         "isFlaggedFraud": 0})[COLS]
