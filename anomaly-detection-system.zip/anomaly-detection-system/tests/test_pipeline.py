import numpy as np
import pandas as pd
import pytest
from src import cleaning, evaluation, generate_data, ingestion, pipeline


@pytest.fixture(scope="module")
def run():
    raw, truth = generate_data.generate(n_accounts=150, n_txn=8000, seed=7)
    df = ingestion.validate_schema(raw.astype(object).where(raw.notna(), ""))
    return pipeline.run(df), truth


def test_schema_validation_rejects_missing_columns():
    with pytest.raises(ValueError):
        ingestion.validate_schema(pd.DataFrame({"transaction_id": ["1"]}))


def test_quality_checks_on_handmade_records():
    raw = pd.DataFrame({
        "row_id": [1, 2, 3, 4], "transaction_id": ["A", "A", "B", "C"], "account_id": ["X", "X", "X", ""],
        "timestamp": ["2026-01-01 10:00:00", "2026-01-01 10:00:00", "not a date", "2026-01-01 10:00:00"],
        "amount": ["100", "100", "50", "-5"], "transaction_type": ["payment", "payment", "DEPOSIT", "PAYMENT"],
        "merchant_category": ["GROCERY", "GROCERY", "BOGUS", "GROCERY"], "channel": ["WEB"] * 4, "location": ["Chennai"] * 4,
        "balance_before": ["1000", "1000", "1000", "1000"], "balance_after": ["900", "900", "1500", "1005"]})
    issues = cleaning.quality_checks(raw, cleaning.clean(raw))
    got = set(zip(issues.row_id, issues.issue_type))
    assert {(1, "DUPLICATE_RECORD"), (2, "DUPLICATE_RECORD"), (3, "MALFORMED_TIMESTAMP"), (3, "INVALID_CATEGORY"),
            (3, "BALANCE_MISMATCH"), (4, "MISSING_REQUIRED_FIELD"), (4, "INVALID_AMOUNT")} <= got
    assert (1, "BALANCE_MISMATCH") not in got          # 1000 - 100 = 900 is consistent


def test_bad_records_are_retained_not_dropped(run):
    out, _ = run
    assert len(out["clean"]) == len(out["results"]) and out["clean"]["row_id"].is_unique
    assert (out["clean"]["data_quality_status"] == "ISSUE").any()


def test_every_flag_has_a_reason(run):
    r = run[0]["results"]
    assert (r.loc[r.anomaly_flag, "reason"].str.len() > 0).all()


def test_injected_anomaly_detection_quality(run):
    out, truth = run
    ev = evaluation.evaluate(out["clean"], out["results"], truth)
    assert ev["combined"]["recall"] >= 0.95 and ev["combined"]["precision"] >= 0.9
    assert ev["combined"]["recall"] >= ev["isolation_forest_only"]["recall"]


def test_normal_records_mostly_not_flagged(run):
    out, truth = run
    d = out["clean"][["row_id", "transaction_id"]].merge(out["results"], on="row_id")
    normal = d[~d.transaction_id.isin(set(truth.transaction_id))]
    assert normal["anomaly_flag"].mean() < 0.01


def test_pipeline_is_deterministic(run):
    raw, _ = generate_data.generate(n_accounts=150, n_txn=8000, seed=7)
    df = ingestion.validate_schema(raw.astype(object).where(raw.notna(), ""))
    a = pipeline.run(df)["results"]["final_score"].to_numpy()
    assert np.allclose(a, run[0]["results"]["final_score"].to_numpy())
