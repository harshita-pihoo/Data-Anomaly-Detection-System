# Financial Transaction Data Quality & Anomaly Detection System

An end-to-end analytics pipeline: ingest transactions → profile → clean & validate → store in PostgreSQL →
rule-based checks + Isolation Forest → explainable anomaly scores → analyst dashboard with review workflow.

> **Responsible-use note.** An anomaly means a record is *unusual under the configured rules and model*. It is a
> prioritisation aid for human review — **not** a finding of fraud, misuse or control failure. All data here is synthetic.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python -m src.generate_data          # synthetic data + injected ground truth  (data/raw/)
python -m src.pipeline               # profile, clean, detect, evaluate, save to DB
streamlit run dashboard/app.py       # analyst dashboard
pytest                               # tests
```
**Database.** By default results go to a local SQLite file so the project runs anywhere. For PostgreSQL:
copy `.env.example` → `.env`, set `DATABASE_URL`, export it (`export $(cat .env | xargs)`), and re-run the pipeline.
The pipeline applies `sql/schema.sql` itself. Credentials are read from the environment only. Analytical queries are in
`sql/analysis_queries.sql` (PostgreSQL dialect).

## Running on PaySim (public dataset)
1. Download **PaySim** from Kaggle (`ealaxi/paysim1`, file `PS_20174392719_1491204439457_log.csv`, ~470 MB; needs a free
   Kaggle login) and save it as `data/raw/paysim.csv`.
2. Run: `python -m src.pipeline --dataset paysim --sample 200000` (add `--sample 0` for all ~6.3M rows — slow and memory-heavy).
3. Open `data/processed/profile.json` first, then `evaluation.json`, then the dashboard.

`src/paysim_adapter.py` documents exactly how columns are mapped. Things that are **derived, not observed**: `transaction_id`
(row number), `timestamp` (anchor date + `step` hours, so hourly resolution only), `merchant_category` (from the `nameDest`
M/C prefix) and `channel` (constant). `isFraud` is used **only** for evaluation, never as a feature or rule input. The dataset
documentation warns the balance columns are unreliable for fraud detection, so the ML model uses no balance-derived feature
under this profile; balance consistency remains a data-quality check (with a low weight until you have reviewed how often it fires).

What to expect (verify from `profile.json`, don't assume): PaySim has no duplicate IDs and few repeat accounts, so the
per-account history rule and duplicate rule will do little; detection leans on the Isolation Forest (amount, type, time features),
and precision will be far lower than on the synthetic set because fraud is ~0.1% of rows. Report whatever you measure.
This adapter was tested on a mock file in PaySim's column layout, not the real file — settings in
`config.PROFILES["paysim"]` may need tuning once you see real output.

## Architecture
```
CSV/synthetic ─► ingestion ─► profiling ─► cleaning + quality checks ─► PostgreSQL
                                                   │
                                   features ──► rules (interpretable) ─┐
                                        └────► Isolation Forest ───────┴─► combined score + reason ─► anomaly_results
                                                                                   │
                                                   SQL/Pandas analytics ◄──────────┴─► Streamlit dashboard ─► review_log
```
| Module | Role |
|---|---|
| `src/generate_data.py` | Synthetic normal data + documented injected anomalies (ground truth saved separately) |
| `src/ingestion.py` | Load as strings (preserve originals), schema validation, surrogate `row_id` |
| `src/profiling.py` | Missing values, duplicates, distributions, IQR/z-score outliers → `profile.json` |
| `src/cleaning.py` | Standardise fields; quality checks produce issues — bad records are **flagged, never dropped** |
| `src/features.py` | Rolling 90-day account median, burst counts, 24h frequency, time since previous, channel/category frequency |
| `src/rules.py` | Deterministic rules, each with a human-readable reason |
| `src/anomaly_model.py` | Isolation Forest + configurable weighted combination |
| `src/evaluation.py` | Precision/recall vs injected truth: rules-only vs ML-only vs combined |
| `src/paysim_adapter.py` | Maps the public PaySim dataset into this schema (`--dataset paysim`) |
| `src/database.py` | Postgres/SQLite access, review recording |
| `dashboard/app.py` | KPIs, trends, breakdowns, amount distribution, top accounts, filters, drill-down, analyst review |

## Detection logic
**Data-quality checks:** missing required fields, duplicate `transaction_id`, non-numeric / non-positive amounts, invalid
type/category/channel, malformed or implausible timestamps, balance inconsistency
(`before ∓ amount ≠ after`, direction by transaction type).

**Behavioural rules:** amount ≥ 8× the account's prior 90-day median; ≥ 5 transactions by one account within 10 minutes.

**Isolation Forest features:** amount, log-amount, amount ÷ account median, 24h transaction count, log time-since-previous,
channel frequency, category frequency, amount ÷ balance. No demographic/personal attributes are used.

**Combination** (all in `src/config.py`): `final = 0.5·rule_score + 0.5·ml_score`; flag if `final ≥ 0.34`. Consequence: any
triggered rule is sufficient to flag (rules are deterministic controls); a record with no rule hit needs `ml_score ≥ 0.68`.
ML-only flags are worded "Model identified this record as unusual based on the selected features" — no causal claim.

## Results — synthetic dataset (seed 42: 20,180 rows, 480 injected anomalies)
| Approach | Precision | Recall | F1 |
|---|---|---|---|
| Rules only | 1.000 | 0.981 | 0.991 |
| Isolation Forest only | 0.501 | 0.421 | 0.458 |
| **Combined** | 0.968 | 0.998 | 0.983 |

Combined recall by injected type: duplicates, balance mismatches, missing fields, invalid categories, malformed timestamps,
negative amounts, bursts = 100%; 20×-amount outliers = 99%. The 16 false positives all come from ML-only flags.

**Read these numbers honestly.**
- The injected anomaly types were designed by the same author as the rules, so high rule recall is expected — it shows the
  pipeline works end to end, not that it would generalise to real-world fraud patterns.
- Isolation Forest alone is weak here, which is realistic: its value is catching cases rules miss (e.g. a large amount for an
  account with too little history for the 90-day median), and it produced the only misses-turned-hits in the combined result.
- Metrics are computed at `transaction_id` level. Balances are generated per record, not as a chained ledger.
- To test sensitivity, vary `IF_PARAMS["contamination"]`, `FLAG_THRESHOLD`, `HIGH_AMOUNT_RATIO` in `config.py` and re-run.

## Database design
`accounts`, `transactions` (cleaned records, surrogate `row_id`), `data_quality_issues`, `anomaly_results`
(separate so detection can be re-run without touching source data), `review_log`. Re-running the pipeline rebuilds the data
tables and keeps `review_log`, but per-record `review_status` resets to `PENDING` (the log still holds the history).

## Audit trail
Each run writes `data/processed/model_audit.json` (model, parameters, features, weights, thresholds), `profile.json` and
`evaluation.json`.

## Limitations / before real-world use
Synthetic data only; rule thresholds are global rather than per-segment; no drift monitoring; Isolation Forest is refit on the
full batch (not incremental); batch processing in Pandas would need chunking or SQL push-down for millions of rows; real
deployment would need access control, encryption, and validation against labelled investigation outcomes.
