"""Behavioural features, computed per account on time-sorted valid records (vectorised)."""
import numpy as np
import pandas as pd
from . import config

FEATURE_COLS = config.ML_FEATURES  # default list; the model reads config.ML_FEATURES at run time


def _prior_median(v: pd.DataFrame) -> pd.Series:
    """Rolling median of the account's PRIOR transactions in the history window. Only accounts with enough rows."""
    eligible = v[v.groupby("_a")["_a"].transform("size") >= config.HISTORY_MIN_TXNS]
    parts = [pd.Series(g.set_index("timestamp")["amount"]
                       .rolling(config.HISTORY_WINDOW, closed="left", min_periods=config.HISTORY_MIN_TXNS)
                       .median().to_numpy(), index=g.index)
             for _, g in eligible.groupby("_a", sort=False)]
    return pd.concat(parts).reindex(v.index) if parts else pd.Series(np.nan, index=v.index)


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    v = df.dropna(subset=["account_id", "timestamp", "amount"])
    v = v[v["amount"] > 0].copy()
    v["_a"] = pd.factorize(v["account_id"])[0]
    v["_t"] = (v["timestamp"] - v["timestamp"].min()).dt.total_seconds().astype("int64")
    v = v.sort_values(["_a", "_t"], kind="stable")

    # one sorted key per (account, time): a window never crosses accounts because S exceeds span + any window
    span = int(v["_t"].max()) + 1
    S = span + 2 * max(86400, config.BURST_WINDOW_SECONDS) + 1
    key = v["_a"].to_numpy(np.int64) * S + v["_t"].to_numpy(np.int64)
    i = np.arange(len(key))

    def counts(w):  # (window ending at txn, window starting at txn), both include the txn itself
        return (i + 1 - np.searchsorted(key, key - w, side="left"),
                np.searchsorted(key, key + w, side="right") - i)

    b10, f10 = counts(config.BURST_WINDOW_SECONDS)
    b24, _ = counts(86400)
    v["burst_count"] = np.maximum(b10, f10)
    v["txn_count_24h"] = b24
    v["secs_since_prev"] = v.groupby("_a")["_t"].diff()
    v["acct_median_90d"] = _prior_median(v)

    f = v.set_index("row_id")[["burst_count", "txn_count_24h", "secs_since_prev", "acct_median_90d",
                               "amount", "channel", "merchant_category", "balance_before"]]
    f["amount_ratio"] = (f["amount"] / f["acct_median_90d"]).fillna(1.0)
    f["log_amount"] = np.log1p(f["amount"])
    f["log_secs_since_prev"] = np.log1p(f["secs_since_prev"].fillna(7 * 86400))
    f["channel_freq"] = f["channel"].map(df["channel"].value_counts(normalize=True)).fillna(0)
    f["category_freq"] = f["merchant_category"].map(df["merchant_category"].value_counts(normalize=True)).fillna(0)
    f["amount_to_balance"] = (f["amount"] / f["balance_before"]).clip(0, 10).fillna(0)
    f["type_freq"] = df.set_index("row_id")["transaction_type"].map(
        df["transaction_type"].value_counts(normalize=True)).reindex(f.index).fillna(0)
    cols = ["amount", "log_amount", "amount_ratio", "txn_count_24h", "log_secs_since_prev", "channel_freq",
            "category_freq", "amount_to_balance", "type_freq", "acct_median_90d", "burst_count"]
    return f.reindex(df["row_id"])[cols]
