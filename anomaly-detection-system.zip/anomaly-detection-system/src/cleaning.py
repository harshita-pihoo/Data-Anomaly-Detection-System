"""Standardise fields and run data-quality checks. Bad records are FLAGGED, never deleted (traceability)."""
import numpy as np
import pandas as pd
from . import config

TEXT_COLS = ["transaction_id", "account_id", "transaction_type", "merchant_category", "channel", "location"]
UPPER_COLS = ["transaction_type", "merchant_category", "channel"]


def _blank(s: pd.Series) -> pd.Series:
    return s.isna() | (s.astype(str).str.strip() == "")


def clean(raw: pd.DataFrame) -> pd.DataFrame:
    df = raw.copy()
    for c in TEXT_COLS:
        df[c] = df[c].astype("object").where(~_blank(df[c]), np.nan)
        df[c] = df[c].str.strip()
    for c in UPPER_COLS:
        df[c] = df[c].str.upper()
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    for c in ["amount", "balance_before", "balance_after"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def quality_checks(raw: pd.DataFrame, df: pd.DataFrame) -> pd.DataFrame:
    """Return one row per (record, issue): row_id, issue_type, detail."""
    out = []

    def add(mask, issue, detail):
        mask = mask.fillna(False).astype(bool)
        d = pd.DataFrame({"row_id": df.loc[mask, "row_id"]})
        d["issue_type"] = issue
        d["detail"] = detail(df.loc[mask]) if callable(detail) else detail
        out.append(d)

    for c in config.NOT_NULL_COLUMNS:
        add(_blank(raw[c]), "MISSING_REQUIRED_FIELD", f"Required field '{c}' is missing")
    add(~_blank(raw["timestamp"]) & df["timestamp"].isna(), "MALFORMED_TIMESTAMP", "Timestamp could not be parsed")
    add(df["timestamp"].notna() & ((df["timestamp"] < config.MIN_PLAUSIBLE_DATE) | (df["timestamp"] > pd.Timestamp.now())),
        "OUT_OF_RANGE", "Timestamp outside plausible range")
    for c in ["amount", "balance_before", "balance_after"]:
        add(~_blank(raw[c]) & df[c].isna(), "INVALID_AMOUNT", f"'{c}' is not numeric")
    add(df["amount"] <= 0, "INVALID_AMOUNT", lambda d: "Non-positive amount (" + d["amount"].round(2).astype(str) + ")")
    add(df["amount"] > config.MAX_PLAUSIBLE_AMOUNT, "OUT_OF_RANGE", "Amount exceeds plausible maximum")
    for col, valid in [("transaction_type", config.VALID_TYPES), ("merchant_category", config.VALID_CATEGORIES),
                       ("channel", config.VALID_CHANNELS)]:
        add(df[col].notna() & ~df[col].isin(valid), "INVALID_CATEGORY",
            lambda d, col=col: f"Invalid {col} '" + d[col].astype(str) + "'")
    counts = df.groupby("transaction_id")["row_id"].transform("count")
    add(df["transaction_id"].notna() & (counts > 1), "DUPLICATE_RECORD",
        lambda d: "transaction_id appears " + counts[d.index].astype(str) + " times")
    sign = np.where(df["transaction_type"].isin(config.DEBIT_TYPES), -1.0, 1.0)
    diff = (df["balance_before"] + sign * df["amount"] - df["balance_after"]).abs()
    add(diff > config.BALANCE_TOLERANCE, "BALANCE_MISMATCH",
        lambda d: "balance_after differs from expected by " + diff[d.index].round(2).astype(str))
    cols = ["row_id", "issue_type", "detail"]
    return pd.concat(out, ignore_index=True)[cols] if out else pd.DataFrame(columns=cols)


def attach_status(df: pd.DataFrame, issues: pd.DataFrame) -> pd.DataFrame:
    reasons = issues.groupby("row_id")["detail"].agg("; ".join)
    df = df.copy()
    df["data_quality_reason"] = df["row_id"].map(reasons)
    df["data_quality_status"] = np.where(df["data_quality_reason"].notna(), "ISSUE", "OK")
    return df
