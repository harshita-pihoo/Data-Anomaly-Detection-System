"""End-to-end pipeline:  python -m src.pipeline [--csv path] [--no-db]"""
import argparse
import json
import logging
import pandas as pd
from . import config, ingestion, cleaning, profiling, features, rules, anomaly_model, database, evaluation, paysim_adapter

log = logging.getLogger("pipeline")


def run(raw: pd.DataFrame) -> dict:
    """Pure in-memory pipeline (no I/O) so it is easy to test."""
    df = cleaning.clean(raw)
    issues = cleaning.quality_checks(raw, df)
    df = cleaning.attach_status(df, issues)
    feats = features.build_features(df)
    rule_df = rules.apply_rules(feats, issues)
    ml_df, audit = anomaly_model.score(feats)
    results = anomaly_model.combine(rule_df, ml_df)
    audit.update({"weights": {"rule": config.W_RULE, "ml": config.W_ML}, "threshold": config.FLAG_THRESHOLD,
                  "rule_weights": config.RULE_WEIGHTS, "high_amount_ratio": config.HIGH_AMOUNT_RATIO})
    v = df.dropna(subset=["account_id"])
    g = v.groupby("account_id")
    accounts = pd.DataFrame({
        "first_seen": g["timestamp"].min(), "last_seen": g["timestamp"].max(), "txn_count": g.size(),
        "median_amount": g["amount"].median(),
        "home_location": g["location"].agg(lambda s: s.mode().iat[0] if s.notna().any() else None)}).reset_index()
    return {"clean": df, "issues": issues, "features": feats, "results": results, "accounts": accounts,
            "audit": audit, "profile": profiling.profile(raw, df, issues)}


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", choices=["synthetic", "paysim"], default="synthetic")
    ap.add_argument("--csv", help="input CSV (default: data/raw/transactions.csv, or data/raw/paysim.csv for paysim)")
    ap.add_argument("--sample", type=int, default=200_000, help="paysim only: random sample size (0 = all rows)")
    ap.add_argument("--no-db", action="store_true")
    a = ap.parse_args()

    if a.dataset == "paysim":
        config.apply_profile("paysim")
        raw, truth = paysim_adapter.load(a.csv or config.ROOT / "data/raw/paysim.csv", a.sample)
        raw = ingestion.validate_schema(raw)
    else:
        raw = ingestion.load_csv(a.csv or config.RAW_PATH)
        truth = pd.read_csv(config.TRUTH_PATH) if config.TRUTH_PATH.exists() else None
    out = run(raw)
    config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    profiling.save(out["profile"], config.PROCESSED_DIR / "profile.json")
    (config.PROCESSED_DIR / "model_audit.json").write_text(json.dumps(out["audit"], indent=2, default=str))

    r = out["results"]
    log.info("Rows=%d  quality-issue rows=%d  flagged=%d (%.2f%%)", len(r), out["issues"]["row_id"].nunique(),
             r["anomaly_flag"].sum(), 100 * r["anomaly_flag"].mean())

    if truth is not None:
        ev = evaluation.evaluate(out["clean"], r, truth)
        (config.PROCESSED_DIR / "evaluation.json").write_text(json.dumps(ev, indent=2))
        for k in ["rules_only", "isolation_forest_only", "combined"]:
            log.info("%-22s precision=%.3f recall=%.3f f1=%.3f", k, ev[k]["precision"], ev[k]["recall"], ev[k]["f1"])

    if not a.no_db:
        eng = database.get_engine()
        database.save_results(eng, {"accounts": out["accounts"],
            "transactions": out["clean"][["row_id"] + config.REQUIRED_COLUMNS + ["data_quality_status", "data_quality_reason"]],
            "data_quality_issues": out["issues"], "anomaly_results": r})
        log.info("Saved to %s", eng.url.render_as_string(hide_password=True))


if __name__ == "__main__":
    main()
