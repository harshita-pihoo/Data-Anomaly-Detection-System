"""DB access. PostgreSQL via DATABASE_URL (recommended); falls back to local SQLite so the project runs anywhere."""
import os
from pathlib import Path
import pandas as pd
from sqlalchemy import create_engine, text
from . import config

SCHEMA_SQL = config.ROOT / "sql/schema.sql"
DATA_TABLES = ["data_quality_issues", "anomaly_results", "transactions", "accounts"]   # child -> parent


def get_engine():
    url = os.getenv("DATABASE_URL", config.DEFAULT_SQLITE_URL)
    if url.startswith("sqlite"):
        Path(config.PROCESSED_DIR).mkdir(parents=True, exist_ok=True)
    return create_engine(url)


def is_postgres(engine) -> bool:
    return engine.dialect.name == "postgresql"


def save_results(engine, tables: dict):
    """Postgres: apply schema, empty data tables (review_log is preserved), append. SQLite: replace tables."""
    if is_postgres(engine):
        with engine.begin() as c:
            c.exec_driver_sql(SCHEMA_SQL.read_text())
            c.exec_driver_sql("TRUNCATE " + ", ".join(DATA_TABLES) + " RESTART IDENTITY CASCADE")
        for name in ["accounts", "transactions", "data_quality_issues", "anomaly_results"]:
            tables[name].to_sql(name, engine, if_exists="append", index=False, chunksize=5000, method="multi")
    else:
        for name, df in tables.items():
            df.to_sql(name, engine, if_exists="replace", index=False, chunksize=500)
        with engine.begin() as c:
            c.execute(text("CREATE TABLE IF NOT EXISTS review_log (review_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                           "row_id INTEGER NOT NULL, reviewer TEXT, outcome TEXT NOT NULL, comment TEXT, "
                           "reviewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"))


def query(engine, sql, params=None) -> pd.DataFrame:
    with engine.connect() as c:
        return pd.read_sql(text(sql), c, params=params)


def record_review(engine, row_id: int, reviewer: str, outcome: str, comment: str = ""):
    with engine.begin() as c:
        c.execute(text("INSERT INTO review_log (row_id, reviewer, outcome, comment) VALUES (:r, :v, :o, :c)"),
                  {"r": row_id, "v": reviewer, "o": outcome, "c": comment})
        c.execute(text("UPDATE anomaly_results SET review_status = :o WHERE row_id = :r"), {"o": outcome, "r": row_id})
