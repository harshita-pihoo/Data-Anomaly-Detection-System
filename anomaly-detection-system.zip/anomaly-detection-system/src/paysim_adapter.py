"""Adapter: PaySim (Kaggle 'ealaxi/paysim1', file PS_20174392719_1491204439457_log.csv) -> this project's schema.

PaySim columns: step,type,amount,nameOrig,oldbalanceOrg,newbalanceOrig,nameDest,oldbalanceDest,newbalanceDest,isFraud,isFlaggedFraud

Mapping (be explicit about what is derived, not observed):
  transaction_id    -> "PS" + original row number            (PaySim has no id column; derived)
  account_id        -> nameOrig
  timestamp         -> 2026-01-01 + step hours                (hourly resolution only; anchor date is arbitrary)
  amount            -> amount
  transaction_type  -> type (unchanged)
  merchant_category -> MERCHANT if nameDest starts with 'M' else CUSTOMER   (derived from destination id prefix)
  channel           -> constant MOBILE_MONEY                  (derived; PaySim has no channel)
  location          -> empty                                  (not in PaySim)
  balance_before/after -> oldbalanceOrg / newbalanceOrig
isFraud is used ONLY as evaluation ground truth. It is never a model input or a rule input.
"""
import numpy as np
import pandas as pd
from . import config

USECOLS = ["step", "type", "amount", "nameOrig", "oldbalanceOrg", "newbalanceOrig", "nameDest", "isFraud"]
ANCHOR = pd.Timestamp("2026-01-01")


def load(path, sample: int = 200_000, seed: int = 42):
    """Return (raw_df_in_project_schema_as_strings, truth_df). Uniform random sample keeps the fraud rate."""
    rng = np.random.default_rng(seed)
    total = sum(len(c) for c in pd.read_csv(path, usecols=["step"], chunksize=1_000_000))
    keep_p = 1.0 if not sample or sample >= total else sample / total
    parts = []
    for ch in pd.read_csv(path, usecols=USECOLS, chunksize=500_000):
        parts.append(ch[rng.random(len(ch)) < keep_p] if keep_p < 1 else ch)
    d = pd.concat(parts)
    missing = set(USECOLS) - set(d.columns)
    if missing:
        raise ValueError(f"Not a PaySim file; missing columns {sorted(missing)}")
    raw = pd.DataFrame({
        "transaction_id": "PS" + d.index.astype(str).str.zfill(7),
        "account_id": d["nameOrig"].astype(str),
        "timestamp": (ANCHOR + pd.to_timedelta(d["step"].astype(int), unit="h")).dt.strftime("%Y-%m-%d %H:%M:%S"),
        "amount": d["amount"].astype(str),
        "transaction_type": d["type"].astype(str),
        "merchant_category": np.where(d["nameDest"].astype(str).str.startswith("M"), "MERCHANT", "CUSTOMER"),
        "channel": "MOBILE_MONEY", "location": "",
        "balance_before": d["oldbalanceOrg"].astype(str), "balance_after": d["newbalanceOrig"].astype(str)})
    raw = raw.reset_index(drop=True)
    fraud = d.reset_index(drop=True)["isFraud"].astype(int) == 1
    truth = pd.DataFrame({"transaction_id": raw.loc[fraud, "transaction_id"],
                          "anomaly_type": "paysim_fraud_" + d.reset_index(drop=True).loc[fraud, "type"].str.lower()})
    return raw, truth.reset_index(drop=True)
