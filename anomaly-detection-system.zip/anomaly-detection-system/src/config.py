"""Central, documented configuration. Every threshold/weight lives here so runs are auditable."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW_PATH = ROOT / "data/raw/transactions.csv"
TRUTH_PATH = ROOT / "data/raw/ground_truth.csv"
PROCESSED_DIR = ROOT / "data/processed"
DEFAULT_SQLITE_URL = f"sqlite:///{PROCESSED_DIR / 'anomaly.db'}"

REQUIRED_COLUMNS = ["transaction_id", "account_id", "timestamp", "amount", "transaction_type",
                    "merchant_category", "channel", "location", "balance_before", "balance_after"]
NOT_NULL_COLUMNS = ["transaction_id", "account_id", "timestamp", "amount", "transaction_type",
                    "merchant_category", "channel", "balance_before", "balance_after"]

VALID_TYPES = {"PAYMENT", "TRANSFER", "WITHDRAWAL", "DEPOSIT"}
DEBIT_TYPES = {"PAYMENT", "TRANSFER", "WITHDRAWAL"}          # balance_after = before - amount
VALID_CATEGORIES = {"GROCERY", "ELECTRONICS", "TRAVEL", "UTILITIES", "DINING",
                    "HEALTHCARE", "ENTERTAINMENT", "OTHER"}
VALID_CHANNELS = {"WEB", "MOBILE", "ATM", "POS"}

# --- data-quality thresholds
BALANCE_TOLERANCE = 0.01
MAX_PLAUSIBLE_AMOUNT = 10_000_000
MIN_PLAUSIBLE_DATE = "2000-01-01"

# --- behavioural rule thresholds
HIGH_AMOUNT_RATIO = 8.0          # amount / account's prior 90-day median
HISTORY_WINDOW = "90D"
HISTORY_MIN_TXNS = 5
BURST_COUNT = 5                  # >= N txns by one account ...
BURST_WINDOW_SECONDS = 600       # ... inside this window

# --- score combination (documented + configurable; a prioritisation aid, NOT a fraud probability)
RULE_WEIGHTS = {
    "DUPLICATE_RECORD": 0.9, "MISSING_REQUIRED_FIELD": 0.8, "INVALID_VALUE": 0.8,
    "BALANCE_MISMATCH": 0.8, "HIGH_AMOUNT_VS_HISTORY": 0.8, "TXN_BURST": 0.7,
}
W_RULE, W_ML = 0.5, 0.5
# final = W_RULE*rule_score + W_ML*ml_score. Threshold 0.34 means: any triggered rule (min weight 0.7 -> 0.35) is
# enough to flag a record (rules are deterministic controls); a record with NO rule hit needs ml_score >= 0.68.
FLAG_THRESHOLD = 0.34

# --- Isolation Forest
IF_PARAMS = {"n_estimators": 200, "contamination": 0.02, "random_state": 42}
ML_FEATURES = ["amount", "log_amount", "amount_ratio", "txn_count_24h", "log_secs_since_prev",
               "channel_freq", "category_freq", "amount_to_balance"]

# --- dataset profiles: override the settings above for a different source dataset
PROFILES = {
    "paysim": {
        # PaySim: 5 transaction types, no channel/location/category, hourly time steps, mostly one-off accounts.
        "VALID_TYPES": {"CASH_IN", "CASH_OUT", "DEBIT", "PAYMENT", "TRANSFER"},
        "DEBIT_TYPES": {"CASH_OUT", "DEBIT", "PAYMENT", "TRANSFER"},        # CASH_IN credits the origin account
        "VALID_CATEGORIES": {"MERCHANT", "CUSTOMER"},                      # derived from nameDest prefix (M... / C...)
        "VALID_CHANNELS": {"MOBILE_MONEY"},                                # constant: all rows are one mobile-money service
        "NOT_NULL_COLUMNS": ["transaction_id", "account_id", "timestamp", "amount", "transaction_type",
                             "merchant_category", "balance_before", "balance_after"],
        "BURST_WINDOW_SECONDS": 3600,                                      # timestamps only have hourly resolution
        # BALANCE_MISMATCH weight is deliberately low (0.3*0.5 < threshold): informational until profile.json is reviewed.
        "RULE_WEIGHTS": {**RULE_WEIGHTS, "BALANCE_MISMATCH": 0.3},
        # Dataset docs say balance columns are unreliable for fraud detection (fraud rows are cancelled), so the
        # ML model uses no balance-derived feature; balance consistency stays a data-quality check only.
        "ML_FEATURES": ["amount", "log_amount", "amount_ratio", "txn_count_24h", "log_secs_since_prev",
                        "category_freq", "type_freq"],
    }
}


def apply_profile(name: str):
    """Override module-level settings. Other modules read config.X at call time, so this takes effect globally."""
    globals().update(PROFILES[name])
