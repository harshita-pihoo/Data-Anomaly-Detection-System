"""Evaluate against injected ground truth (id level): rules-only vs ML-only vs combined."""
import pandas as pd

DQ_TYPES = ["duplicate", "missing_field", "invalid_category", "malformed_timestamp", "negative_amount", "balance_mismatch"]
BEHAVIOURAL = ["high_amount", "burst"]


def evaluate(transactions: pd.DataFrame, results: pd.DataFrame, truth: pd.DataFrame) -> dict:
    d = transactions[["row_id", "transaction_id"]].merge(results, on="row_id")
    truth_ids = set(truth["transaction_id"])
    out = {}
    for name, col in [("rules_only", "rule_flag"), ("isolation_forest_only", "ml_flag"), ("combined", "anomaly_flag")]:
        pred = set(d.loc[d[col], "transaction_id"].dropna())
        tp = len(pred & truth_ids)
        p = tp / len(pred) if pred else 0.0
        r = tp / len(truth_ids)
        out[name] = {"flagged_ids": len(pred), "true_positives": tp, "false_positives": len(pred) - tp,
                     "precision": round(p, 4), "recall": round(r, 4),
                     "f1": round(2 * p * r / (p + r), 4) if p + r else 0.0}
    pred = set(d.loc[d["anomaly_flag"], "transaction_id"].dropna())
    out["combined_recall_by_type"] = {
        t: round(len(pred & set(g["transaction_id"])) / len(g), 4) for t, g in truth.groupby("anomaly_type")}
    out["injected_total"] = len(truth_ids)
    return out
