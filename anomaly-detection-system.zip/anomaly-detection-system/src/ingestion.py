import logging
import pandas as pd
from . import config

log = logging.getLogger(__name__)


def load_csv(path=config.RAW_PATH) -> pd.DataFrame:
    """Load everything as strings so original values stay intact for quality checks."""
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    return validate_schema(df)


def validate_schema(df: pd.DataFrame) -> pd.DataFrame:
    missing = [c for c in config.REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Input is missing required columns: {missing}")
    df = df[config.REQUIRED_COLUMNS].copy()
    df.insert(0, "row_id", range(1, len(df) + 1))   # surrogate key: transaction_id may repeat (duplicates)
    log.info("Loaded %d rows", len(df))
    return df
