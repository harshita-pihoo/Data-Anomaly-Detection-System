"""Dataset profiling: completeness, duplicates, distributions, IQR outliers."""
import json
import numpy as np
import pandas as pd
from . import config


def profile(raw: pd.DataFrame, df: pd.DataFrame, issues: pd.DataFrame) -> dict:
    amt = df["amount"].dropna()
    q1, q3 = amt.quantile([0.25, 0.75])
    iqr = q3 - q1
    return {
        "rows": int(len(df)),
        "date_range": [str(df["timestamp"].min()), str(df["timestamp"].max())],
        "missing_by_column": {c: int((raw[c].isna() | (raw[c].astype(str).str.strip() == "")).sum())
                              for c in config.REQUIRED_COLUMNS},
        "duplicate_transaction_id_rows": int(df["transaction_id"].duplicated(keep=False).sum()),
        "records_with_quality_issues": int(issues["row_id"].nunique()),
        "pct_records_with_quality_issues": round(100 * issues["row_id"].nunique() / len(df), 2),
        "issues_by_type": issues["issue_type"].value_counts().to_dict(),
        "amount_summary": {k: round(float(v), 2) for k, v in amt.describe(percentiles=[.5, .95, .99]).items()},
        "amount_skew": round(float(amt.skew()), 2),
        "amount_iqr_outliers": int(((amt < q1 - 1.5 * iqr) | (amt > q3 + 1.5 * iqr)).sum()),
        "amount_zscore_gt3": int((((amt - amt.mean()) / amt.std()).abs() > 3).sum()),
        "value_counts": {c: df[c].value_counts(dropna=False).head(10).to_dict()
                         for c in ["transaction_type", "channel", "merchant_category"]},
    }


def save(p: dict, path):
    with open(path, "w") as f:
        json.dump(p, f, indent=2, default=str)
