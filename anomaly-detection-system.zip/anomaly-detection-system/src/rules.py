"""Interpretable rules. Every flag carries a human-readable reason."""
from collections import defaultdict
import pandas as pd
from . import config

ISSUE_TO_RULE = {
    "DUPLICATE_RECORD": "DUPLICATE_RECORD", "MISSING_REQUIRED_FIELD": "MISSING_REQUIRED_FIELD",
    "BALANCE_MISMATCH": "BALANCE_MISMATCH", "INVALID_AMOUNT": "INVALID_VALUE", "INVALID_CATEGORY": "INVALID_VALUE",
    "MALFORMED_TIMESTAMP": "INVALID_VALUE", "OUT_OF_RANGE": "INVALID_VALUE"}


def apply_rules(feats: pd.DataFrame, issues: pd.DataFrame) -> pd.DataFrame:
    flags = pd.DataFrame(False, index=feats.index, columns=list(config.RULE_WEIGHTS))
    reasons = defaultdict(list)

    for r in issues.itertuples():
        flags.at[r.row_id, ISSUE_TO_RULE[r.issue_type]] = True
        reasons[r.row_id].append(r.detail)

    hi = feats["acct_median_90d"].notna() & (feats["amount_ratio"] >= config.HIGH_AMOUNT_RATIO)
    flags.loc[hi, "HIGH_AMOUNT_VS_HISTORY"] = True
    for rid, ratio in feats.loc[hi, "amount_ratio"].items():
        reasons[rid].append(f"Transaction amount is {ratio:.1f}x the account's 90-day median")

    bu = feats["burst_count"] >= config.BURST_COUNT
    flags.loc[bu, "TXN_BURST"] = True
    for rid, n in feats.loc[bu, "burst_count"].items():
        reasons[rid].append(f"{int(n)} transactions by the same account within {config.BURST_WINDOW_SECONDS // 60} minutes")

    weights = pd.Series(config.RULE_WEIGHTS)
    # a rule whose weight alone can't reach the flag threshold is informational (shown in reasons, doesn't set rule_flag)
    active = weights.index[weights * config.W_RULE >= config.FLAG_THRESHOLD]
    out = pd.DataFrame({"rule_score": (flags.astype(float) @ weights).clip(upper=1.0),
                        "rule_flag": flags[active].any(axis=1),
                        "rules_triggered": flags.apply(lambda r: ",".join(r.index[r]), axis=1),
                        "rule_reasons": pd.Series({k: "; ".join(v) for k, v in reasons.items()})})
    out["rule_reasons"] = out["rule_reasons"].fillna("")
    return out
