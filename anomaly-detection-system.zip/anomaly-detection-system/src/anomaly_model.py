"""Isolation Forest scoring + combination with rule score."""
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from . import config


def score(feats: pd.DataFrame, params=None):
    params = params or config.IF_PARAMS
    cols = config.ML_FEATURES
    X = feats[cols]
    ok = X.notna().all(axis=1)                      # records lacking key fields are covered by quality rules
    model = IsolationForest(**params).fit(X[ok])
    raw = -model.decision_function(X[ok])           # higher = more unusual
    norm = (raw - raw.min()) / (raw.max() - raw.min() + 1e-12)
    out = pd.DataFrame({"ml_score": 0.0, "ml_flag": False}, index=feats.index)
    out.loc[ok, "ml_score"] = norm
    out.loc[ok, "ml_flag"] = model.predict(X[ok]) == -1
    audit = {"model": "IsolationForest", "params": params, "features": cols,
             "records_scored": int(ok.sum()), "records_skipped_missing_features": int((~ok).sum())}
    return out, audit


def combine(rules: pd.DataFrame, ml: pd.DataFrame) -> pd.DataFrame:
    r = rules.join(ml)
    r["final_score"] = (config.W_RULE * r["rule_score"] + config.W_ML * r["ml_score"]).round(4)
    r["anomaly_flag"] = r["final_score"] >= config.FLAG_THRESHOLD
    ml_only = r["anomaly_flag"] & r["ml_flag"] & ~r["rule_flag"]
    r["anomaly_types"] = [", ".join(filter(None, [rt, "ML_ISOLATION_FOREST" if m else ""]))
                          for rt, m in zip(r["rules_triggered"], r["ml_flag"])]
    ml_txt = r["ml_score"].map(lambda s: f"Model identified this record as unusual based on the selected features (model score {s:.2f})")
    reason = r["rule_reasons"].where(~r["ml_flag"], r["rule_reasons"] + np.where(r["rule_reasons"] != "", "; ", "") + ml_txt)
    r["reason"] = reason.where(r["anomaly_flag"], "")
    r["review_status"] = np.where(r["anomaly_flag"], "PENDING", "NOT_REQUIRED")
    r.index.name = "row_id"
    return r.reset_index()[["row_id", "rule_flag", "ml_flag", "rule_score", "ml_score", "final_score",
                            "anomaly_flag", "anomaly_types", "reason", "review_status"]]
