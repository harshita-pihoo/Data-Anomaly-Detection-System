"""Synthetic transaction generator with documented, injected anomalies (ground truth saved separately).

Normal data: per-account lognormal spending level, mostly-preferred channel, mostly-home location.
Balances are generated per record (before -> after), not as a chained running ledger.
All data is synthetic; no real bank or customer data is used.
"""
import argparse
import numpy as np
import pandas as pd
from . import config

CITIES = ["Chennai", "Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Kolkata", "Pune"]
TYPES, TYPE_P = ["PAYMENT", "TRANSFER", "WITHDRAWAL", "DEPOSIT"], [0.5, 0.2, 0.15, 0.15]
FMT = "%Y-%m-%d %H:%M:%S"

INJECTIONS = {"high_amount": 100, "balance_mismatch": 80, "missing_field": 50, "invalid_category": 30,
              "malformed_timestamp": 20, "negative_amount": 20, "duplicate": 60}
N_BURSTS, BURST_SIZE = 15, 8


def _balances(df):
    sign = np.where(df["transaction_type"].isin(config.DEBIT_TYPES), -1.0, 1.0)
    df["balance_after"] = (df["balance_before"] + sign * df["amount"]).round(2)
    return df


def generate(n_accounts=300, n_txn=20000, days=120, seed=42, start="2026-01-01"):
    rng = np.random.default_rng(seed)
    acc = pd.DataFrame({
        "account_id": [f"ACC{1000 + i}" for i in range(n_accounts)],
        "base": rng.lognormal(np.log(3000), 0.6, n_accounts),
        "home": rng.choice(CITIES, n_accounts),
        "pref_channel": rng.choice(sorted(config.VALID_CHANNELS), n_accounts)})
    i = rng.integers(0, n_accounts, n_txn)
    ts = pd.Timestamp(start) + pd.to_timedelta(rng.integers(0, days * 86400, n_txn), unit="s")
    df = pd.DataFrame({
        "account_id": acc["account_id"].values[i], "timestamp": ts,
        "amount": (acc["base"].values[i] * rng.lognormal(0, 0.35, n_txn)).round(2),
        "transaction_type": rng.choice(TYPES, n_txn, p=TYPE_P),
        "merchant_category": rng.choice(sorted(config.VALID_CATEGORIES), n_txn),
        "channel": np.where(rng.random(n_txn) < 0.7, acc["pref_channel"].values[i],
                            rng.choice(sorted(config.VALID_CHANNELS), n_txn)),
        "location": np.where(rng.random(n_txn) < 0.9, acc["home"].values[i], rng.choice(CITIES, n_txn)),
        "balance_before": rng.uniform(20000, 180000, n_txn).round(2)})
    df = _balances(df.sort_values("timestamp").reset_index(drop=True))
    df.insert(0, "transaction_id", [f"T{n:06d}" for n in range(1, n_txn + 1)])

    perm = rng.permutation(n_txn)
    pos, truth = 0, []

    def take(k):
        nonlocal pos
        idx = perm[pos:pos + k]
        pos += k
        return idx

    idx = take(INJECTIONS["high_amount"])
    df.loc[idx, "amount"] = (df.loc[idx, "amount"] * rng.uniform(15, 30, len(idx))).round(2)
    df.loc[idx] = _balances(df.loc[idx].copy())
    truth += [(t, "high_amount") for t in df.loc[idx, "transaction_id"]]

    idx = take(INJECTIONS["balance_mismatch"])
    df.loc[idx, "balance_after"] += rng.choice([-1, 1], len(idx)) * rng.uniform(500, 20000, len(idx)).round(2)
    truth += [(t, "balance_mismatch") for t in df.loc[idx, "transaction_id"]]

    idx = take(INJECTIONS["negative_amount"])
    df.loc[idx, "amount"] *= -1
    truth += [(t, "negative_amount") for t in df.loc[idx, "transaction_id"]]

    idx = take(INJECTIONS["invalid_category"])
    df.loc[idx, "merchant_category"] = rng.choice(["CRYPTO_XYZ", "UNKNOWN", "MISC99"], len(idx))
    truth += [(t, "invalid_category") for t in df.loc[idx, "transaction_id"]]

    dup_src = take(INJECTIONS["duplicate"])
    dups = df.loc[dup_src].copy()
    truth += [(t, "duplicate") for t in dups["transaction_id"]]

    out = df.copy()
    out["timestamp"] = out["timestamp"].dt.strftime(FMT)
    out["amount"] = out["amount"].astype(object)
    idx = take(INJECTIONS["malformed_timestamp"])
    out.loc[idx, "timestamp"] = "2026-13-45 99:99:99"
    truth += [(t, "malformed_timestamp") for t in out.loc[idx, "transaction_id"]]
    idx = take(INJECTIONS["missing_field"])
    cols = rng.choice(["account_id", "amount", "merchant_category", "channel"], len(idx))
    for r, c in zip(idx, cols):
        out.loc[r, c] = np.nan
    truth += [(t, "missing_field") for t in out.loc[idx, "transaction_id"]]

    dups["timestamp"] = dups["timestamp"].dt.strftime(FMT)
    bursts, n_next = [], n_txn + 1
    for _ in range(N_BURSTS):
        a = acc.iloc[rng.integers(n_accounts)]
        t0 = pd.Timestamp(start) + pd.Timedelta(seconds=int(rng.integers(0, days * 86400)))
        b = pd.DataFrame({
            "transaction_id": [f"T{n_next + k:06d}" for k in range(BURST_SIZE)], "account_id": a["account_id"],
            "timestamp": [t0 + pd.Timedelta(seconds=int(s)) for s in np.sort(rng.integers(0, 540, BURST_SIZE))],
            "amount": (a["base"] * rng.lognormal(0, 0.35, BURST_SIZE)).round(2),
            "transaction_type": "PAYMENT", "merchant_category": rng.choice(sorted(config.VALID_CATEGORIES), BURST_SIZE),
            "channel": a["pref_channel"], "location": a["home"],
            "balance_before": rng.uniform(50000, 150000, BURST_SIZE).round(2)})
        n_next += BURST_SIZE
        b = _balances(b)
        b["timestamp"] = b["timestamp"].dt.strftime(FMT)
        bursts.append(b)
        truth += [(t, "burst") for t in b["transaction_id"]]

    final = pd.concat([out, dups, *bursts], ignore_index=True).sample(frac=1, random_state=seed).reset_index(drop=True)
    return final[config.REQUIRED_COLUMNS], pd.DataFrame(truth, columns=["transaction_id", "anomaly_type"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--n-txn", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    raw, truth = generate(n_txn=a.n_txn, seed=a.seed)
    config.RAW_PATH.parent.mkdir(parents=True, exist_ok=True)
    raw.to_csv(config.RAW_PATH, index=False)
    truth.to_csv(config.TRUTH_PATH, index=False)
    print(f"wrote {len(raw):,} rows -> {config.RAW_PATH}; {len(truth)} injected anomalies -> {config.TRUTH_PATH}")
