"""Analyst dashboard.  Run:  streamlit run dashboard/app.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import plotly.express as px
import streamlit as st
from src import database

st.set_page_config(page_title="Transaction Anomaly Review", layout="wide")
engine = database.get_engine()

QUERY = """SELECT t.row_id, t.transaction_id, t.account_id, t."timestamp", t.amount, t.transaction_type,
       t.merchant_category, t.channel, t.location, t.data_quality_status,
       a.anomaly_flag, a.anomaly_types, a.reason, a.final_score, a.rule_score, a.ml_score, a.review_status
FROM transactions t JOIN anomaly_results a USING (row_id)"""


@st.cache_data(ttl=30)
def load() -> pd.DataFrame:
    df = database.query(engine, QUERY)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["anomaly_flag"] = df["anomaly_flag"].astype(bool)
    df["date"] = df["timestamp"].dt.date
    return df


try:
    data = load()
except Exception:
    st.error("No results found. Run `python -m src.generate_data && python -m src.pipeline` first.")
    st.stop()

st.title("Financial Transaction Data Quality & Anomaly Detection")
st.caption("Decision-support only: a flag means a record is unusual under the configured rules/model and needs human "
           "review. It is not a finding of fraud. Data is synthetic.")

# ---- filters
sb = st.sidebar
sb.header("Filters")
dmin, dmax = data["timestamp"].min().date(), data["timestamp"].max().date()
dr = sb.date_input("Date range", (dmin, dmax), min_value=dmin, max_value=dmax)
types_all = sorted({t.strip() for s in data.loc[data.anomaly_flag, "anomaly_types"].dropna() for t in s.split(",") if t.strip()})
f_type = sb.multiselect("Transaction type", sorted(data["transaction_type"].dropna().unique()))
f_chan = sb.multiselect("Channel", sorted(data["channel"].dropna().unique()))
f_cat = sb.multiselect("Merchant category", sorted(data["merchant_category"].dropna().unique()))
f_acc = sb.text_input("Account ID contains")
f_an = sb.multiselect("Anomaly type", types_all)

d = data.copy()
if len(dr) == 2:
    d = d[(d["date"] >= dr[0]) & (d["date"] <= dr[1]) | d["timestamp"].isna()]
for col, sel in [("transaction_type", f_type), ("channel", f_chan), ("merchant_category", f_cat)]:
    if sel:
        d = d[d[col].isin(sel)]
if f_acc:
    d = d[d["account_id"].fillna("").str.contains(f_acc, case=False)]
if f_an:
    d = d[d["anomaly_types"].fillna("").apply(lambda s: any(t in s for t in f_an))]
flag = d[d["anomaly_flag"]]

# ---- KPIs
k = st.columns(5)
k[0].metric("Transactions", f"{len(d):,}")
k[1].metric("Flagged", f"{len(flag):,}")
k[2].metric("Anomaly rate", f"{100 * len(flag) / max(len(d), 1):.2f}%")
k[3].metric("Data-quality issues", f"{(d['data_quality_status'] == 'ISSUE').sum():,}")
k[4].metric("Pending review", f"{(flag['review_status'] == 'PENDING').sum():,}")

# ---- charts
c1, c2 = st.columns(2)
daily = flag.dropna(subset=["timestamp"]).groupby("date").size().reset_index(name="anomalies")
c1.plotly_chart(px.line(daily, x="date", y="anomalies", title="Flagged transactions per day"), width="stretch")
dim = c2.selectbox("Break down anomaly rate by", ["channel", "transaction_type", "merchant_category"])
rate = d.groupby(dim).agg(txns=("row_id", "size"), flagged=("anomaly_flag", "sum")).reset_index()
rate["anomaly_rate_pct"] = (100 * rate["flagged"] / rate["txns"]).round(2)
c2.plotly_chart(px.bar(rate, x=dim, y="anomaly_rate_pct", hover_data=["txns", "flagged"],
                       title=f"Anomaly rate by {dim} (%)"), width="stretch")

c3, c4 = st.columns(2)
pos = d[d["amount"] > 0].assign(status=lambda x: x["anomaly_flag"].map({True: "Flagged", False: "Normal"}))
c3.plotly_chart(px.histogram(pos, x="amount", color="status", log_x=True, nbins=60, barmode="overlay", opacity=0.7,
                             title="Amount distribution: normal vs flagged (log scale)"), width="stretch")
top = flag.groupby("account_id").size().nlargest(10).reset_index(name="flagged")
c4.plotly_chart(px.bar(top, x="flagged", y="account_id", orientation="h", title="Top accounts by flagged records")
                .update_yaxes(autorange="reversed"), width="stretch")

# ---- anomaly table + review
st.subheader("Flagged records (highest priority first)")
show = flag.sort_values("final_score", ascending=False)[
    ["row_id", "transaction_id", "account_id", "timestamp", "amount", "channel", "anomaly_types",
     "reason", "final_score", "review_status"]]
st.dataframe(show, width="stretch", hide_index=True, height=350)
st.download_button("Download filtered flagged records (CSV)", show.to_csv(index=False), "flagged_records.csv")

st.subheader("Analyst review")
if len(show):
    with st.form("review"):
        rid = st.selectbox("Record (row_id)", show["row_id"].tolist())
        row = data[data["row_id"] == rid].iloc[0]
        st.write(f"**{row.transaction_id}** · {row.account_id} · amount {row.amount} · {row.reason}")
        who = st.text_input("Reviewer")
        outcome = st.selectbox("Outcome", ["CONFIRMED_ISSUE", "FALSE_POSITIVE", "NEEDS_FOLLOW_UP"])
        note = st.text_area("Comment")
        if st.form_submit_button("Save review"):
            database.record_review(engine, int(rid), who, outcome, note)
            load.clear()
            st.success("Review saved.")
else:
    st.info("No flagged records for the current filters.")
