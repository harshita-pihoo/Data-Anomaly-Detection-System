-- PostgreSQL schema. Safe to re-run (IF NOT EXISTS). Original transactions are kept separate from
-- anomaly results so detection can be re-run without touching the underlying data.
CREATE TABLE IF NOT EXISTS accounts (
    account_id     TEXT PRIMARY KEY,
    first_seen     TIMESTAMP,
    last_seen      TIMESTAMP,
    txn_count      INTEGER,
    median_amount  NUMERIC(14,2),
    home_location  TEXT
);

CREATE TABLE IF NOT EXISTS transactions (
    row_id               INTEGER PRIMARY KEY,           -- surrogate key (transaction_id can repeat)
    transaction_id       TEXT,
    account_id           TEXT REFERENCES accounts(account_id),
    "timestamp"          TIMESTAMP,
    amount               NUMERIC(14,2),
    transaction_type     TEXT,
    merchant_category    TEXT,
    channel              TEXT,
    location             TEXT,
    balance_before       NUMERIC(14,2),
    balance_after        NUMERIC(14,2),
    data_quality_status  TEXT NOT NULL DEFAULT 'OK',
    data_quality_reason  TEXT
);

CREATE TABLE IF NOT EXISTS data_quality_issues (
    row_id      INTEGER NOT NULL REFERENCES transactions(row_id),
    issue_type  TEXT NOT NULL,
    detail      TEXT
);

CREATE TABLE IF NOT EXISTS anomaly_results (
    row_id         INTEGER PRIMARY KEY REFERENCES transactions(row_id),
    rule_flag      BOOLEAN NOT NULL,
    ml_flag        BOOLEAN NOT NULL,
    rule_score     DOUBLE PRECISION,
    ml_score       DOUBLE PRECISION,
    final_score    DOUBLE PRECISION,
    anomaly_flag   BOOLEAN NOT NULL,
    anomaly_types  TEXT,
    reason         TEXT,
    review_status  TEXT NOT NULL DEFAULT 'PENDING'
);

CREATE TABLE IF NOT EXISTS review_log (
    review_id    SERIAL PRIMARY KEY,
    row_id       INTEGER NOT NULL,
    reviewer     TEXT,
    outcome      TEXT NOT NULL,
    comment      TEXT,
    reviewed_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_txn_account   ON transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_txn_time      ON transactions("timestamp");
CREATE INDEX IF NOT EXISTS idx_txn_txid      ON transactions(transaction_id);
CREATE INDEX IF NOT EXISTS idx_anom_flag     ON anomaly_results(anomaly_flag);
CREATE INDEX IF NOT EXISTS idx_dqi_type      ON data_quality_issues(issue_type);
