-- PostgreSQL analysis queries (each maps to a question in the project brief).

-- Q1. Anomalies per day
SELECT t."timestamp"::date AS day, COUNT(*) AS anomalies
FROM anomaly_results a JOIN transactions t USING (row_id)
WHERE a.anomaly_flag AND t."timestamp" IS NOT NULL
GROUP BY 1 ORDER BY 1;

-- Q2. Anomaly rate by channel
SELECT t.channel, COUNT(*) AS txns, SUM(a.anomaly_flag::int) AS anomalies,
       ROUND(100.0 * AVG(a.anomaly_flag::int), 2) AS anomaly_rate_pct
FROM transactions t JOIN anomaly_results a USING (row_id)
WHERE t.channel IS NOT NULL
GROUP BY t.channel ORDER BY anomaly_rate_pct DESC;

-- Q3. Accounts with the most flagged transactions
SELECT t.account_id, COUNT(*) AS flagged, ROUND(SUM(t.amount), 2) AS flagged_amount
FROM transactions t JOIN anomaly_results a USING (row_id)
WHERE a.anomaly_flag AND t.account_id IS NOT NULL
GROUP BY t.account_id ORDER BY flagged DESC LIMIT 10;

-- Q4. Average amount: flagged vs non-flagged
SELECT a.anomaly_flag, COUNT(*) AS txns, ROUND(AVG(t.amount), 2) AS avg_amount,
       PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY t.amount) AS median_amount
FROM transactions t JOIN anomaly_results a USING (row_id)
GROUP BY a.anomaly_flag;

-- Q5. Duplicate transaction IDs
SELECT transaction_id, COUNT(*) AS occurrences
FROM transactions WHERE transaction_id IS NOT NULL
GROUP BY transaction_id HAVING COUNT(*) > 1 ORDER BY occurrences DESC, transaction_id;

-- Q6. Percentage of records with data-quality issues, and breakdown by issue type
SELECT ROUND(100.0 * COUNT(*) FILTER (WHERE data_quality_status = 'ISSUE') / COUNT(*), 2) AS pct_with_issues
FROM transactions;

SELECT issue_type, COUNT(*) AS issues, COUNT(DISTINCT row_id) AS records
FROM data_quality_issues GROUP BY issue_type ORDER BY issues DESC;

-- Q7. Categories with sudden week-over-week volume changes (CTE + window function)
WITH weekly AS (
    SELECT merchant_category, DATE_TRUNC('week', "timestamp")::date AS week, COUNT(*) AS txns
    FROM transactions
    WHERE merchant_category IS NOT NULL AND "timestamp" IS NOT NULL
    GROUP BY 1, 2
), chg AS (
    SELECT *, LAG(txns) OVER (PARTITION BY merchant_category ORDER BY week) AS prev_txns FROM weekly
)
SELECT merchant_category, week, prev_txns, txns, ROUND(100.0 * (txns - prev_txns) / prev_txns, 1) AS pct_change
FROM chg WHERE prev_txns > 0 ORDER BY ABS(txns - prev_txns) / prev_txns::numeric DESC LIMIT 10;

-- Q8. Flagged records still awaiting analyst review, highest priority first
SELECT t.transaction_id, t.account_id, t.amount, a.final_score, a.anomaly_types, a.reason
FROM anomaly_results a JOIN transactions t USING (row_id)
WHERE a.anomaly_flag AND a.review_status = 'PENDING'
ORDER BY a.final_score DESC LIMIT 25;
